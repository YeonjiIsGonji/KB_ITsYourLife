package assignment.ch06.sec06.exam01;

public class Car {
    String model; // null
    boolean start; // false
    int speed; // 0

}

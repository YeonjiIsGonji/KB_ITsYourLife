package assignment.ch16.sec03;

@FunctionalInterface
public interface Workable {
    void work(String name, String job);
}

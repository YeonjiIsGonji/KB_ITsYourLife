package assignment.ch16.sec01;

@FunctionalInterface
public interface Calculable {
    void calculate(int x, int y);
}

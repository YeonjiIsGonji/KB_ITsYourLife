package assignment.ch16.sec02.exam01;

@FunctionalInterface
public interface Workable {
    void work();
}
